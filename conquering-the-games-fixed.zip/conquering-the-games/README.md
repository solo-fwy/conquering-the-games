# WCG Gaming

Mobile-friendly WCG gaming community hub.

Includes:
- WCG neon UI and mobile dropdown navigation
- Signup/login with bcrypt password hashing
- Expiring email verification tokens
- Profile menu with username, email and logout
- Admin-only Socials
- Mod/admin Resellers
- File Share with 470 MB limit
- VirusTotal safety warning
- Mod/admin file removal

Run:
npm install
npm start

Environment variables:
SESSION_SECRET
ADMIN_EMAIL
ADMIN_PASSWORD
SMTP_HOST
SMTP_PORT
SMTP_USER
SMTP_PASS
SMTP_FROM
PUBLIC_URL

For production, use persistent storage/database hosting and object storage for large uploads.
WCG does not claim to virus-scan uploaded files.
